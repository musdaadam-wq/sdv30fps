namespace Fps30
{
    /// <summary>User settings, stored in config.json next to the mod.</summary>
    public class ModConfig
    {
        /// <summary>The frame rate to run the game at.</summary>
        public int TargetFps { get; set; } = 30;
    }
}
