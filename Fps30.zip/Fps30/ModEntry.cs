using System;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewValley;

namespace Fps30
{
    /// <summary>Runs Stardew Valley at a fixed frame rate (30 FPS by default) without any manual commands.</summary>
    public class ModEntry : Mod
    {
        private TimeSpan Target;

        public override void Entry(IModHelper helper)
        {
            ModConfig config = helper.ReadConfig<ModConfig>();
            int fps = Math.Clamp(config.TargetFps, 1, 1000);
            if (fps != config.TargetFps)
            {
                config.TargetFps = fps;
                helper.WriteConfig(config);
            }
            this.SetTarget(fps);

            helper.Events.GameLoop.GameLaunched += (_, _) => this.Apply();
            // Re-check every tick: cheap, and keeps the cap in place if the game resets its timing
            // (e.g. after changing video options or returning to the title screen).
            helper.Events.GameLoop.UpdateTicked += (_, _) => this.Apply();

            helper.ConsoleCommands.Add("fps", "Change the frame rate until restart.\nUsage: fps <number>  (e.g. fps 60)", this.OnFpsCommand);
        }

        private void SetTarget(int fps)
        {
            this.Target = TimeSpan.FromSeconds(1.0 / fps);
        }

        private void Apply()
        {
            Game1 game = Game1.game1;
            if (game == null)
                return;

            if (!game.IsFixedTimeStep)
                game.IsFixedTimeStep = true;
            if (game.TargetElapsedTime != this.Target)
                game.TargetElapsedTime = this.Target;
        }

        private void OnFpsCommand(string command, string[] args)
        {
            if (args.Length != 1 || !int.TryParse(args[0], out int fps) || fps < 1 || fps > 1000)
            {
                this.Monitor.Log("Usage: fps <number between 1 and 1000>", LogLevel.Warn);
                return;
            }
            this.SetTarget(fps);
            this.Apply();
            this.Monitor.Log($"Frame rate set to {fps} FPS (until restart; edit config.json to make it permanent).", LogLevel.Info);
        }
    }
}
