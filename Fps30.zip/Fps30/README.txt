Fps30 - SMAPI mod, runs Stardew Valley at 30 FPS automatically.

BUILD (needs the .NET 6 SDK and Stardew Valley + SMAPI installed):
  cd Fps30
  dotnet build -c Release
The build auto-detects your game folder and copies the finished mod into Mods/Fps30.
If it can't find the game, add <GamePath>C:\path\to\Stardew Valley</GamePath> to Fps30.csproj.

MANUAL INSTALL: put Fps30.dll + manifest.json into  Stardew Valley/Mods/Fps30/

CONFIG: after first launch, Mods/Fps30/config.json -> "TargetFps": 30
Console command (temporary): fps 60
